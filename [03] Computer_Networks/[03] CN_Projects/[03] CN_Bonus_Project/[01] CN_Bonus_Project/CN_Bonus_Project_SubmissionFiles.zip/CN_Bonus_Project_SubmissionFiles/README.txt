Project Source code link: https://github.com/Kishan-Kumar-Zalavadia/CN_HTTP_flood_attack
_____________________________________________________________________________________________________________________________________________

HTTP flood attack

Prerequisites:
- Python 3.x
- Scapy

_____________________________________________________________________________________________________________________________________________

Instructions to run the Project:


Run the server first using the below command:
	python main_server.py

Run the attack using the below command:
	python main.py 100
100 represents number of clients
Each client makes 5 request to the server.
_____________________________________________________________________________________________________________________________________________